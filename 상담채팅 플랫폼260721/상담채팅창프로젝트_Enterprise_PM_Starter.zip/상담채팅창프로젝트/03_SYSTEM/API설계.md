# API 설계

REST/WebSocket API 명세 초안.
