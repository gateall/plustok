# DB 설계

chat_room, chat_message, customer, ai_history 등 핵심 테이블.
