# Gemini

멀티모달 활용.
