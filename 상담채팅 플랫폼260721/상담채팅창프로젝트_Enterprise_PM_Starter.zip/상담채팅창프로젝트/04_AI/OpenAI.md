# OpenAI

범용 생성 및 함수 호출.
